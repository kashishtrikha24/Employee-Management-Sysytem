
package employ_managmentsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Splash extends JFrame implements ActionListener {
    Splash(){
        getContentPane().setBackground(Color.BLACK);
        setLayout(null);
        
        JLabel heading =new JLabel("EMPLOYEE MANAGMENT SYSTEM");
        heading.setBounds(110,30,1200,60);
        heading.setFont(new Font("serit",Font.PLAIN,60));
        heading.setForeground(Color.WHITE);
        add(heading);
        
         ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icon/front.jpg"));
         Image i2 =i1.getImage().getScaledInstance(1400,2000,Image.SCALE_DEFAULT);
        ImageIcon i3 =new ImageIcon(i2);
         JLabel image =new JLabel(i3);
         image.setBounds(50,100,1050,500);
         add(image);
         
        
         
        
        JButton clickhere =new JButton("CLICK HERE TO CONTINUE");
        clickhere.setBounds(400,400,300,70);
        clickhere.setBackground(Color.BLACK);
        clickhere.setForeground(Color.WHITE);
           image. add(clickhere);
        clickhere.addActionListener(this);
        
        setSize(1170,650);
        setLocation(200,50);
        setVisible(true);
        
    }
    
    public void actionPerformed(ActionEvent ae){
        setVisible(false);
        new login();
    }
    
    public static void main(String args[]){
        
    Splash s =new Splash();
    }
    
    
    
    
    
    
    
    
    
}
