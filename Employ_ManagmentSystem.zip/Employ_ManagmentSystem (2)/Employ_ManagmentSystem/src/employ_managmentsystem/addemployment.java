
package employ_managmentsystem;
import java.awt.*;
import javax.swing.*;
    import com.toedter.calendar.JDateChooser;
    import java.util.*;   
        import java.awt.event.*;

public class addemployment extends JFrame  implements ActionListener{
    
    Random ran =new Random();
    int number=ran.nextInt(999999);
    
    JTextField tfname,tffname,tfsalary,tfaddress,tfphoneno,tfemail,tfadharno,tfdesignation;
    JDateChooser dcdob;
    JComboBox cbeducation;
    JLabel lblempId;
    JButton add,Back;
    
    addemployment(){
        
        
        
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        
        
        JLabel heading =new JLabel("Add Employment Detial");
        heading.setBounds(320,30,500,50);
        heading.setFont(new Font ("SAN_SERIF" ,Font.BOLD,25));
        add(heading);
        
        JLabel labelname =new JLabel("Name");
        labelname.setBounds(50, 150, 150, 30);
         heading.setFont(new Font ("SERIF" ,Font.PLAIN,20));
        add(labelname);
        
        tfname =new JTextField();
        tfname.setBounds(200,150,150,30);
        add(tfname);
        
         JLabel labelfname =new JLabel("Father's name");
        labelfname.setBounds(400, 150, 150, 30);
         labelfname.setFont(new Font ("SERIF" ,Font.PLAIN,20));
        add(labelfname);
        
        
       tffname =new JTextField();
        tffname.setBounds(600,150,150,30);
        add(tffname);
        
        JLabel labeldob=new JLabel("Date of Birth");
        labeldob.setBounds(50, 200, 150, 30);
         labeldob.setFont(new Font ("SERIF" ,Font.PLAIN,20));
        add(labeldob);
        
         dcdob =new JDateChooser();
         dcdob.setBounds(200,200,150,30);
         add(dcdob);
        
          JLabel labelsalary =new JLabel("Salary");
        labelsalary.setBounds(400, 200, 150, 30);
         labelsalary.setFont(new Font ("SERIF" ,Font.PLAIN,20));
        add(labelsalary);
        
        tfsalary =new JTextField();
       tfsalary.setBounds(600,200,150,30);
        add(tfsalary);
        
         JLabel labeladdress =new JLabel("Address");
        labeladdress.setBounds(50, 250, 150, 30);
         labeladdress.setFont(new Font ("SERIF" ,Font.PLAIN,20));
        add(labeladdress);
        
         tfaddress =new JTextField();
        tfaddress.setBounds(200,250,150,30);
        add(tfaddress);
        
         JLabel labelphone =new JLabel("Phone no");
        labelphone.setBounds(400, 250, 150, 30);
         labelphone.setFont(new Font ("SERIF" ,Font.PLAIN,20));
        add(labelphone);
        
        tfphoneno =new JTextField();
        tfphoneno.setBounds(600,250,150,30);
        add(tfphoneno);
        
         JLabel labelemail =new JLabel("E-mail");
        labelemail.setBounds(50, 300, 150, 30);
         labelemail.setFont(new Font ("SERIF" ,Font.PLAIN,20));
        add(labelemail);
        
         tfemail =new JTextField();
        tfemail.setBounds(200,300,150,30);
        add(tfemail);
        
         JLabel labeleducation =new JLabel("Highest Education");
        labeleducation.setBounds(400, 300, 150, 30);
         labeleducation.setFont(new Font ("SERIF" ,Font.PLAIN,20));
        add(labeleducation);
        
        String courses[]={"BBA","BCA"," BA","MBA","MTECH","BTECH","B.COM","MCA","BSC"};
        
        
        cbeducation =new JComboBox(courses);
        cbeducation.setBackground(Color.WHITE);
        cbeducation.setBounds(600,300,150,30);
        add(cbeducation);
        
        JLabel labeldesignation =new JLabel("Designation");
        labeldesignation.setBounds(50, 350, 150, 30);
         labeldesignation.setFont(new Font ("SERIF" ,Font.PLAIN,20));
        add(labeldesignation);
        
         tfdesignation =new JTextField();
        tfdesignation.setBounds(200,350,150,30);
        add(tfdesignation);
        
        JLabel labelaadhar =new JLabel("Adhar no");
        labelaadhar.setBounds(400, 350, 150, 30);
         labelaadhar.setFont(new Font ("SERIF" ,Font.PLAIN,20));
        add(labelaadhar);
        
        tfadharno =new JTextField();
        tfadharno.setBounds(600,350,150,30);
        add(tfadharno);
        
        JLabel labelempId =new JLabel("Employ id ");
        labelempId.setBounds(50, 400, 150, 30);
         labelempId.setFont(new Font ("SERIF" ,Font.PLAIN,20));
        add(labelempId);
        
         lblempId =new JLabel(""+ number);
        lblempId.setBounds(200, 400, 150, 30);
         lblempId.setFont(new Font ("SERIF" ,Font.PLAIN,20));
        add(lblempId);
        
       add= new JButton("Add Details");
         add.setBounds(250,550,150,40);
         add.addActionListener(this);
        add.setBackground(Color.WHITE);
        add.setForeground(Color.BLACK);
         
         add(add);
         
         Back= new JButton("Back");
         Back.setBounds(450,550,150,40);
         Back.addActionListener(this);
         Back.setBackground(Color.WHITE);
        Back.setForeground(Color.BLACK);
         
         
         add(Back);
         
         ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icon/add_employee.jpg"));
         Image i2 =i1.getImage().getScaledInstance(1120,630,Image.SCALE_DEFAULT);
        ImageIcon i3 =new ImageIcon(i2);
         JLabel image =new JLabel(i3);
         image.setBounds(0,0,1120,630);
         add(image);

        
        setSize(900,700);
        setLocation(300,50);
        setVisible(true);
    }
        public void actionPerformed(ActionEvent ae){
            
        if(ae.getSource()==add){
            String name =tfname.getText();
            String fname =tffname.getText();
            String dob = ((JTextField) dcdob.getDateEditor().getUiComponent()).getText();
            String salary = tfsalary.getText();
            String address= tfaddress.getText();
            String phone= tfphoneno.getText();
            String email=tfemail.getText();
            String education =(String )cbeducation.getSelectedItem();
            String designation = tfdesignation.getText();
            String aadhar= tfadharno.getText();
            String empId =lblempId.getText();
        
            try{
                Conn c =new Conn();
                String query=" insert into employee values('"+name+"','"+fname+"','"+dob+"','"+salary+"','"+address+"','"+phone+"','"+email+"','"+education+"','"+designation+"','"+aadhar+"','"+empId+"')";
               c.s.executeUpdate(query);
          JOptionPane.showMessageDialog(null,"Details added Sucessfully");
          setVisible(false);
          new Home();
            }
            
            catch(Exception e){
                e.printStackTrace();
            }
        }
        else{
            setVisible(false);
            new Home();
        }
    }
    
    public static void main(String args[]){
        new addemployment();
    }
}
