
package employ_managmentsystem;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public  class Home extends JFrame implements ActionListener{
    
    JButton add,view,remove,update;
    
    Home(){
        getContentPane().setBackground(Color.WHITE);
         setLayout(null);
         
         
         JLabel heading =new JLabel("Employee Managment System");
         heading.setBounds(620,20,400,40);
         heading.setFont(new Font("serit", Font.BOLD,25));
         add(heading);
         
         add= new JButton("Add Employee");
         add.setBounds(650,80,150,40);
         add.addActionListener(this);
         add(add);
         
         view =new JButton("View Employee");
         view.setBounds(820,80,150,40);
         view.addActionListener(this);
         add(view);
         
          update =new JButton("Update Employee");
         update.setBounds(650,140,150,40);
         update.addActionListener(this);
         add(update);
         
         remove =new JButton("Remove Employee");
         remove.setBounds(820,140,150,40);
         remove.addActionListener(this);
         add(remove);
         
         ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icon/home.jpg"));
         Image i2 =i1.getImage().getScaledInstance(1120,630,Image.SCALE_DEFAULT);
        ImageIcon i3 =new ImageIcon(i2);
         JLabel image =new JLabel(i3);
         image.setBounds(0,0,1120,630);
         add(image);

         image.add(heading);
         
       setSize(1120,630);
       setLocation(250,100);
       setVisible(true);
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()== add){
            setVisible(false);
            new addemployment();
        }else if(ae.getSource()==view){
            setVisible(false);
            new Viewemploy();
            
        }else if(ae.getSource()==update){
             setVisible(false);
             new Viewemploy();
        }else {
            setVisible(false);
            new Removeemployee();
        }
            
        
        
    }
    public static void main(String args[]){
        new Home();
    }
}
